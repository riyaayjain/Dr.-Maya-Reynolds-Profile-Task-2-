## Packages
framer-motion | Page transitions and scroll-triggered animations
react-scroll | Smooth scrolling for navigation links

## Notes
Static images from Unsplash will be used for hero, profile, and decorative elements.
Contact form submits to POST /api/contact using z.coerce where necessary.
